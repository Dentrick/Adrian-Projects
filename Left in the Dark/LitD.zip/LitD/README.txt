##########################################################################
  _           __ _     _         _   _            _____             _    
 | |         / _| |   (_)       | | | |          |  __ \           | |   
 | |     ___| |_| |_   _ _ __   | |_| |__   ___  | |  | | __ _ _ __| | __
 | |    / _ \  _| __| | | '_ \  | __| '_ \ / _ \ | |  | |/ _` | '__| |/ /
 | |___|  __/ | | |_  | | | | | | |_| | | |  __/ | |__| | (_| | |  |   < 
 |______\___|_|  \__| |_|_| |_|  \__|_| |_|\___| |_____/ \__,_|_|  |_|\_\                   
##########################################################################

INSTALLATION INSTRUCTIONS:
1) Install OpenAL using oalinst.exe
2) Run game using LitD.exe
3) Have fun!

DESCRIPTION:
You are a young boy, you do not know how you came to be here, but there are things out there aiming to hurt you.
You must survive the shadows and make it out alive, all while managing your flimsy, dimming electric lantern.
fail to use your wits, and you just might be Left in the Dark.

HOW TO PLAY:
-Use WASD or Arrow keys to move around.
-press Left Shift to sprint.
-Press E or left click to interact with doors and item dispensers.
-Press B to use bait
-Press M or right Click to mark doors

GAMEPLAY:

You are being hunted by the Shadows, a paranormal whorde of the remains of your fellow humans.
-These beings will always chase you if they can smell you in the same room (or even out of rooms if you leave doors open!).
-The usual Shadows will walk slowly towards you and can surround you in groups if too many detect you.
-At about one tile away of distance, an enemy will lunge at you, guaranteeing death.
-Use your stamina sparingly, you never know when you might need it to avoid a certain death!

Luckily, there are multiple item dispensers around.
-Batteries can replenish up to 50% of your total battery. They will be used immediately on pickup.
-Bait can be used to lure away enemies. They are dropped and activate immediately on use. Used with the "B" key.
-Cola can be used to increase your max stamina. They will be used immediately on pickup.
-You can mark doors to indicate you've been there before.

CREDITS:
Music: Originals from Kevin Macleod at incompetech.com
SFX: YouTube Audio Library