﻿1) Install aolinst.exe
2) Play game with PingHero.exe
3) ???
4) Profit